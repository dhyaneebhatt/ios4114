//
//  SearchResultViewController.swift
//  CoreDataTest
//
//  Created by MacStudent on 2018-11-12.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import UIKit
import CoreData //imp , c&p

class SearchResultViewController: UIViewController {

    
    //PLACEHOLDER VAR
    var personName:String = ""
    
    var context:NSManagedObjectContext!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("sterp:2:-->Loaded the second screen!")
        print("DEBUG: Person's name:\(self.personName)")
        // Do any additional setup after loading the view.
        
        //fetch data
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
